package com.java.oops;

// understand class, Methods and Objects
public class GradeBook1 {
	public void displayMessage() {
		System.out.println("Welcome to the Grade Book!");
	}

}
