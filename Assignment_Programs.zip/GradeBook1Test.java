package com.java.oops;

public class GradeBook1Test {

	public static void main(String[] args) {

		// create a GradeBook object and assign it to myGradeBook
		GradeBook1 myGradeBook = new GradeBook1();

		// call myGradeBook's displayMessage method
		myGradeBook.displayMessage();

	}

}
