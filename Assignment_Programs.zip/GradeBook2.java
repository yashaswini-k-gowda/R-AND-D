package com.java.oops;

public class GradeBook2 {
	public void displayMessage(String courseName) {
		System.out.printf("Welcome to the grade book for\n%s!\n", courseName);
	}

}
