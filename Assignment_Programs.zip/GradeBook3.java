package com.java.oops;

//Learning objectives -Instance Variables, set Methods and get Methods
public class GradeBook3 {
	private String courseName; // course name for this GradeBook

	// method to set the course name
	public void setCourseName(String name) {
		courseName = name; // store the course name
	}

	// method to retrieve the course name
	public String getCourseName() {
		return courseName;
	}

	public void displayMessage() {
		// calls getCourseName to get the name of
		// the course this GradeBook represents
		System.out.printf("Welcome to the grade book for\n%s!\n", getCourseName());
	}
}
