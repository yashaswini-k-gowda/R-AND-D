package com.yashu.bank;

public class InsufficientBalException extends Exception {
	InsufficientBalException() {
     super();
		
	}
}
