package com.yashu.bank;

public class MinimumAmountDeposit extends Exception {
	MinimumAmountDeposit(){
		super();
	}
}
