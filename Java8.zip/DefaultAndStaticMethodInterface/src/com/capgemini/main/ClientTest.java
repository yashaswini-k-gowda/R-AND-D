package com.capgemini.main;

import java.util.ArrayList;
import java.util.List;

public class ClientTest {
public static void main(String[] args) {
	MyInterface myInterface=new MyClass();
	List<Student> stuList=new ArrayList<>();
	stuList.add(new Student("Yashu",21));
	stuList.add(new Student("bindu",22));
	stuList.add(new Student("ranju",22));
	
	
	List<Student> sortStudents=myInterface.sortStudents(stuList);
	for(Student student:sortStudents) {
		System.out.println(student.getName()+"\t"+student.getAge());
	}
   MyInterface.greet("ash");
   
   
   
   List<Integer> intList=new ArrayList<>();
   intList.add(300);
   intList.add(400);
   intList.add(600);
  
   Integer maxNum=myInterface.getMaxNum(intList);
   System.out.println("Max Num " +maxNum);
}
}
