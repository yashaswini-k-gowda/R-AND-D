package com.capgemini.main;

import java.util.Collections;
import java.util.List;

public class MyClass  implements MyInterface {

	
	@Override
	public  Integer getMaxNum(List<Integer> intList) {
		Integer maxNum=Collections.max(intList);
		return maxNum;
		
	
	}
}
