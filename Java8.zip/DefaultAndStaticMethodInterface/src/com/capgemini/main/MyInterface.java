package com.capgemini.main;

import java.util.Collections;
import java.util.List;

public  interface MyInterface {
	default public List<Student> sortStudents(List<Student> stuList){
		Collections.sort(stuList);
		return stuList;
	}
		public static void greet(String name) {
			System.out.println("welcome "+name);
		}
		public abstract Integer getMaxNum(List<Integer> intList);
		
		
		
	}

	

	
	
	


