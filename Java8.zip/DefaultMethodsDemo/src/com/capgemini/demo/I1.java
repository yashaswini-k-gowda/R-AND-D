package com.capgemini.demo;

public interface I1 {

default	public void display() {
	System.out.println("I1:display");
}
}
