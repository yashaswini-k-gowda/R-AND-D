package com.capgemini.demo;

public interface I2 {
	default	public void display() {
		System.out.println("I2:display");
	}
}
