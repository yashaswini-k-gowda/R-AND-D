package com.capgemini.demo;

public class welcome implements I1,I2 {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		I2.super.display();
		//I1.super.display();

	}

	
	public static void main(String[] args) {
		welcome wel=new welcome();
		wel.display();
		
	}
}
