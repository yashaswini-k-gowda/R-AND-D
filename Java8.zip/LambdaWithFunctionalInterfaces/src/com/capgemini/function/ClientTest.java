package com.capgemini.function;

public class ClientTest {
public static void main(String[] args) {
	MyInterface1 myInterface=() -> {System.out.println("It is executing using lambda");};
	myInterface.method1();

	MyInterface2 myInterface2=(String name)-> System.out.println("Your name is :"+name);
	myInterface2.method2("yashu");
	
	
	MyInterface3 myInterface3=(String name,int age)-> System.out.println("Your name is :"+name +" "+"age="+age);
	myInterface3.method3("yashu",21);
}
}
