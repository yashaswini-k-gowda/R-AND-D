package com.capgemini.function;

public interface MyInterface1 {

	public  abstract void method1();
	
}
