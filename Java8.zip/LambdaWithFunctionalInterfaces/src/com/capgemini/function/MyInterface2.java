package com.capgemini.function;

public interface MyInterface2 {

	void method2(String name);
	
	
}
