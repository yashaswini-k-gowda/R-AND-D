package com.capgemini.function;

public interface MyInterface3 {
	void method3(String name,int age);
	
}
