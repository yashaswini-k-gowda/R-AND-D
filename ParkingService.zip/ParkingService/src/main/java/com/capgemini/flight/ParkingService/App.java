package com.capgemini.flight.ParkingService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
/**
 * Hello world!
 *
 */
public class App 
{
	

	
	public static void main(String[] args) {
	ParkingDetails park=new ParkingDetails();
	CustomerDetails owner=new CustomerDetails("bindu1322", "9871564361", "11:11");
	park.addCar(new CustomerDetails("yashu","9374987597", "17:00"));
	park.addCar(new CustomerDetails("Sparsh","9374987597", "19:00"));
	park.addCar(new CustomerDetails("ranju","9374987597", "05:00"));
	park.addCar(new CustomerDetails("sowmya","9374987597", "04:00"));
	park.addCar(new CustomerDetails("likitha","8288811768", "12:00"));
	park.addCar(new CustomerDetails("ashish","8288811768", "06:00"));
	park.addCar(new CustomerDetails("ramya","9374987597", "02:00"));
	park.addCar(new CustomerDetails("anu","8288811768", "11:00"));
	park.addCar(new CustomerDetails("ssk","9374987597", "10:00"));
	park.addCar(new CustomerDetails("tharun","8288811768", "04:00"));
	park.addCar(new CustomerDetails("vidya","8288811768", "11:00"));
	park.addCar(owner);
	
	park.getAllCars();
	
	for(Map.Entry e: park.getAllCars()) {
	System.out.println(e.getKey()+" " + e.getValue());
	}
	System.out.println(park.getCarById(owner.getId()));
	

	
	}
	

}
