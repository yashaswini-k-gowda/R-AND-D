package com.capgemini.bank;

public class CurrentAccount extends BankAccount{

	public void withdraw(double amount) {
		
		System.out.println("curent account withdraw method");
	}
	

}
