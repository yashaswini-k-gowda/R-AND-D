package com.capgemini.bank;

public interface Insurance {
	String InsuranceName();
	String InsuranceType();
	double InsuranceAmount();
	

}
