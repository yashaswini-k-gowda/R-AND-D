package com.yashu.parallel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		
		List<Student> list=new ArrayList<>();
		list.add(new Student("yashu",21));
		list.add(new Student("tharu",21));
		list.add(new Student("anu",21));
		Stream<Student> parallelstream=list.parallelStream();
		
		
		parallelstream.forEach(s->doProcess(s));
	}

	private static void doProcess(Student s) {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

}
