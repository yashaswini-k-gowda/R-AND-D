package com.yashu.ref;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
    List<String> collect=Stream.of("a","b","c").filter(e->e.contains("b")).collect(Collectors.toList());

    
    Optional<String> findAny=  collect.stream().findAny();

	
	System.out.println(findAny.get());
	
	Optional<String> findfirst=collect.stream().findFirst();

	System.out.println(findfirst.get());
	}

}
