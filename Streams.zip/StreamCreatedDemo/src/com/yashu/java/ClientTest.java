package com.yashu.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {

		
		String arr[]=new String[] {"a","b","c"};
		Stream<String> stream=Arrays.stream(arr);
		stream.forEach(System.out::println);
		
	Stream<String> of=Stream.of("aa","bb","cc","dd");
	of.forEach(System.out::println);
	
	List<String> list=new ArrayList<>();
	list.add("yashu");
	list.add("bindu");
	list.add("ranju");
	list.add("pragnya");
	Stream<String> stream2=list.stream();
	
	stream2.forEach(System.out::println);
	
	}

}
