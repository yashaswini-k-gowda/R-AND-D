package com.capgemini.test;

import java.util.Arrays;
import java.util.OptionalInt;
import java.util.stream.IntStream;

public class StreamReductionTest {

	public static void main(String[] args) {
 OptionalInt reduced= IntStream.range(1,4).reduce((a,b)->a+b);
	
	System.out.println(reduced.getAsInt());
	
	
	int reducedtwo= IntStream.range(1,4).reduce(10,(a,b)->a+b);
	System.out.println(reducedtwo);

	
	Integer reduce=Arrays.asList(1,2,3).parallelStream().reduce(10,(a,b)->a+b,(a,b)->{System.out.println("x");
	return a+b;
	});
	System.out.println(reduce);

	}

}
