package com.junit;

public class Car {

	private Engine engine;
	private FuelTank fuelTank;
	
	
	
	
	public Car(Engine engine, FuelTank fuelTank) {
		
		this.engine = engine;
		this.fuelTank = fuelTank;
	}
	
	
	public void start() {
		if(engine.isRunning()) {
			throw new IllegalStateException("engine already running");
		}
		
		if(fuelTank.getFuel()==0) {
			throw new IllegalStateException("no fuel ");
		}
		
		engine.start();
		
		if(!engine.isRunning()) {
			throw new IllegalStateException("Started engine but is not running");
		}
	
	
	
	}
	
	public boolean isRunning() {
		return engine.isRunning();
		
	}
	
}
