package swap;

public class Customer {
String customerId,customerName,customerAddress;
String paymentMode;

void addCustomer() {
	
}
void removeCustomer() {
	
}
void updateCustomer() {
	
}

}


