package swap;

public class Goods {

	String goodsId,goodsName;
	int goodsQuantity;
	double goodsPrice;
	
	public void addGoods()
	{
		
	}
	void removeGoods() {
		
	}
	void orderGoods() {
		
	}
	void updateGoods() {
		
	}
	
	
}
