package swap;

public class Supplier {
	String supplierId,supplierName,supplierAddress;
	int quantityOrder;
	String orderId;
	double amount;
	public void addSupplier() {
		
	}
	void removeSupplier() {
		
	}
	void updateSupplier() {
		
	}
	
	
	
	
	

}
