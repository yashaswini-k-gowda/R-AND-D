public class TEST {
	  
	  //public static void main(String args[]) {

	        //int x,y,z;
	//Scanner s=new Scanner(System.in);

	//x=s.nextInt();
	//y=s.nextInt();
public  static int  add(int x,int y) {
 return x+y;
	        
	//System.out.println("Sum of x+y = " + z);
	    
	}
	}