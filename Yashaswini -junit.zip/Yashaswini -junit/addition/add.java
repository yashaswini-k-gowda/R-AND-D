import static org.junit.Assert.*;

import org.junit.Test;
//package com.rithus.junit.example;
public class add {

	@Test
	public void testTEST() {
	//TEST t=new TEST();
	int expect=4;
	//t.TEST(2,2);
   assertEquals(expect,TEST.add(2,2));
	}

}
