package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class alpha {

	@Test
	public void test() {
		assertEquals(10,alphabet.main(5));
	}

}