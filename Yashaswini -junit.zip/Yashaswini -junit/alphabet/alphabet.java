package swap;

public class alphabet {

	
	    public static int main(int a) {
	       int alphabet=65,i,j,n=a;
	int z=0;
	
	for(i=1;i<n;i++)
	{
	   
	    for(j=1;j<=i;j++)
	    {
	    System.out.print((char)alphabet);
	    z++;
	    }
	    alphabet++;
  
	        System.out.println();
	        
	}
	return z;
	    }
	    }
