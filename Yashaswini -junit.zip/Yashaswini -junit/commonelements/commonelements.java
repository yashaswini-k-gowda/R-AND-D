package swap;
public class commonelements{
	
public static int[]  findCommon(int ar1[], int ar2[], int ar3[])
{
  
    int i = 0, j = 0, k = 0;
    int c[]=new int[2];
    int  count=0;
   
    while (i < ar1.length && j < ar2.length && k < ar3.length)
    {
         if (ar1[i] == ar2[j] && ar2[j] == ar3[k])
         {   
        	 System.out.print(ar1[i]+" ");  
         c[count++]=ar1[i];
         i++; j++; k++;
         }

      
         else if (ar1[i] < ar2[j] && ar1[i]<ar3[k])
             i++;

        
         else if (ar2[j] < ar3[k] && ar2[j]<ar1[i])
             j++;

        
         else
             k++;
    }




   

  
    return c;
    
}
}