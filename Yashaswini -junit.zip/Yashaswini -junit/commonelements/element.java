package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class element {

	@Test
	public void test() {
		int a[] = {1, 5, 10, 20, 40, 80};
	    int b[] = {6, 7, 20, 80, 100};
	    int c[] = {3, 4, 15, 20, 30, 70, 80, 120};

	int d[]= {20,80};
	assertArrayEquals(d,commonelements.findCommon(a,b,c));
	}

}
