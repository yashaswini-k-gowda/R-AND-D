package swap;

public class great {

	  
	    public static int main(int x,int y,int z)
	    {
	      
	        if(x>y && x>z)
	        {
	            System.out.println("the greatest value is:"+x);
	            return x;
	        }
	        else if(y>z)
	        {
	            System.out.println("the greatest value is:"+y);
	            return y;
	    }
	        else
	        {
	           System.out.println("the greatest value is:"+z);
	           return z;
	}
	       
	    
	}
}
