package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class greattest {

	@Test
	public void test() {
	int b=9;
	assertEquals(b,great.main(4,7,9));
	
	}

}
