package swap;

public class large {

	

	   public static int[] main(int x[])
	 {
	      
	 int a,i,b,c,n;
	  n=x.length;
	    
	
	   
	    
	 if(n<3)
	  
	 {
	    
	  System.out.print("invalid"); 
	 
	    
	   }
	   
	c=a=b=Integer.MIN_VALUE;
	  
	 for(i=0;i<n;i++)
	  
	 {
	       if(x[i]>a)
	  
	     {
	        
	   c=b;
	           
	b=a;
	          
	 a=x[i];
	     
	  }
	       
	else if(x[i]>b)
	 
	      {
	     
	      
	c=b;
	        
	   b=x[i];
	    
	   }
	       
	else if(x[i]>c)
	 
	 
	     c=x[i];
	 
	  }
	   
	   
	  System.out.print("largest numberis " +a +" "+b +" "+c);
int[] t=new int[3];
t[0]=a;
t[1]=b;
t[2]=c;


	
	   return t;
	   
	       }
	        
	 
	    
	}
