package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class largetest {

	@Test
	public void test() {
		int x[]={5,9,4,87,45};
		int y[]= {87,45,9};
		
		assertArrayEquals(y,large.main(x));
		
	}

}
