package swap;

public class mirrroredstar {

	
	 public static int main(int a) {
	    
	   int i,j,n;
	       n=a;
	       int z=0;
	      
	
	      
	 for(i=1;i<n;i++)
	       {
	    
	       for(j=1;j<=n;j++)
	         
	 
	 {
	              
	 if(j<=n-i)
	              

	 {
	                   
	               
	          
	     System.out.print(" ");
	              
	 }
	       

	else
	       
	{
	          
	 System.out.print("*");
	 z++;
	      }
	       
	    }
	       
	 System.out.println();
	  
	  
	       }  
	 return z;
	   
	 }

	}



