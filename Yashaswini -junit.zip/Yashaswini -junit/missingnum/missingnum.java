package swap;

//import java.util.Scanner;

public class missingnum {
  
  //public static void main(String args[])

 //{
	  public  static int mis(int a[]) 
	  {  
	  
    int j,t;
    // int a[]={1,2,4,5,6};
     int n= a.length;
// Scanner s=new Scanner(System.in);
 //n=s.nextInt();
      t=(n+1)*(n+2)/2;


       for(j=0;j<n;j++)
   {
t=t-a[j];
  //t[0]=t; 
  
  }
 System.out.println(+t);
        return t;
   
       }
 
}   
  
  


