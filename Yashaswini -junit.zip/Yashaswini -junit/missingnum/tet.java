package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class tet {

	@Test
	public void test() {
	int a[]= {1,2,4,5,6};
		assertEquals(3,missingnum.mis(a));
	}

}
