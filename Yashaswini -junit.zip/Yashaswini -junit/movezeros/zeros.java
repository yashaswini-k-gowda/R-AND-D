package swap;

public class zeros {
	

	   
	public static int[] ma(int a[],int n) 
	{
	       int i,j,t=0;
	      
	       
	 
	     
	    
	  
	     for(i=0;i<n;i++){
	  
	   if(a[i]!=0)
	     
	{
	 
	    a[t++]=a[i];
	  
	   }
	     
	}


	     while(t<n)
	    
	 {a[t++]=0;
	   
	 }
	 
	   for(j=0;j<n;j++)
	 
	       System.out.print(a[j]+" ");
	  
	         return a;
	       }
	   
	      
	    
	

}
