package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class zerostest {

	@Test
	public void test() {
		int a[]={1,2,4,5,0,0,0,6};
		int n=8;
		int b[]= {1,2,4,5,6,0,0,0};
		  assertArrayEquals(b,zeros.ma(a,n));
	}

}
