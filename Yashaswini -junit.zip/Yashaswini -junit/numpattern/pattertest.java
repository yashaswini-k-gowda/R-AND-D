package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class patterntest {

	@Test
	public void test() {
		assertEquals(25,pattern.main(5));
	}

}
