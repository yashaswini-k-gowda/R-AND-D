package smallest;

import static org.junit.Assert.*;

import org.junit.Test;

public class smallestTest {

	@Test
	public void test() {
		int expect=2;
		//t.TEST(2,2);
	   assertEquals(expect,smallest.small(2,4,5));
		}

	}


