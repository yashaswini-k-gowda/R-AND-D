package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class sort {

	@Test
	public void test() {
		 int a[] = {45,12,85,32,89,39,69,44,42,1,6,8};
int b[]= {1,6,8,12,32,39,42,44,45,69,85,89};
assertArrayEquals(b,array.main(a));
	}
	
}