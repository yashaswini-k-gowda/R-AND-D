package swap;

public class star {

	
	  public static int main(int a) {
	    
	   int i,j,n;
	 n=a;

	    int z=0;
	 for(i=n;i>0;i--)
	 
	      {
	           
	for(j=1;j<=i;j++)
	    

	       {
	            
	   System.out.print("*");
	     z++;
	      }
	       
	        
	System.out.println();
	  
	  }
	        
	  return z;  
	}

	}



