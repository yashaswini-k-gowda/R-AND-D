package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class startest {

	@Test
	public void test() {
		assertEquals(15,star.main(5));
	}

	

}
