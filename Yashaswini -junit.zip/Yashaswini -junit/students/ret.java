package swap;

public class ret {

	//import java.util.*;
	//import java.lang.*;

	
	    public static int main(int a[])
	    {
	       int c=0;
	        int n=8,i;
	       
	        for(i=0;i<n;i++)
	        {
	            if(a[i]>=86)
	            {
	                System.out.println(a[i]);
	                c++;
	               
	            }
	           
	        }
	     
			return c;
	    }
}