package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class tes {

	@Test
	public void test() {
		 int a[]={25,34,46,90,97,67,89,96};
		 int b[]= {90,97,89,96};
		 assertEquals(4,ret.main(a));
		 
	}

}
