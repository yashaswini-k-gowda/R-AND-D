package digits;

class sumofdigits
{  
    public static int test(int n)
    {
        int sum=0,p;
        while(n!=0)
        {
            p=n%10;
            sum=sum+p;
            n=n/10;
        }
        System.out.println(sum);
        return sum;
    }
}