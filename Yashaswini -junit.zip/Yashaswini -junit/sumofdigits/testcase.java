package digits;

import static org.junit.Assert.*;

import org.junit.Test;

public class testcase {

	@Test
	public void test1() {
		
		
	   assertEquals(3,sumofdigits.test(120));
	}

}
