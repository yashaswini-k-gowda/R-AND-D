package swap;

class Swap

{  
    public static void main(String args[])
    {
        int x=4,y=7,temp;
        temp=x;
        x=y;
        y=temp;
        System.out.println("x="+x);
        System.out.println("y="+y);
    }
    
    public static int[] m1(int x,int y)
    {
   int  	temp=x;
    	x=y;
    	y=temp;
    	int c[]=new int[2];
    	c[0]=x;
    	c[1]=y;
    	return c;
    	
    }
}