package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class sw {

	@Test
	public void test() {
		int c[]= {2,3};
		assertArrayEquals(c,Swap.m1(3,2));
	}

}
