package swap;

class swap

{  
    public static int[] ab(int x,int y)
    {
    	
        x=x+y;
        y=x-y;
        x=x-y;
        int c[]=new int[2];
    	c[0]=x;
    	c[1]=y;
        return c;
       
        
    }
}