package swap;

import static org.junit.Assert.*;

import org.junit.Test;

public class swap2 {

	@Test
	public void test() {
		int c[]= {3,2};
		
		assertArrayEquals(c,swap.ab(2,3));
	}

}
