package uml2;

public class Square extends Rectangle{
	protected  double side;
	
	
	public Square(){
		
	}
	public Square(double side){
		this.side=side;
		
	}
	public Square(double side,String color,boolean filled){
		super();
		this.side=side;
		
		
		
	}
	public double getSide(){
		
		return side;
	}
	public void setSide(double side){
		this.side=side;
	}
	public void setWidth(double side){
		this.width=side;
		
	}
	public void setLength(double side){
		this.length=side;
		
	}
	public String toString(){
		return "color=" +color;
		
	}
	

}
