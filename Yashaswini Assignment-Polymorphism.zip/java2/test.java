package uml2;

public class Test {

	public static void main(String[] args) {
		Circle c=new Circle(3.0);
		//Circle c=new Circle(3.0);
		System.out.println(c.getRadius());
		System.out.println(c.getArea());
		System.out.println(c.getPerimeter());
		System.out.println(c.toString());
		
		
		
		Rectangle r=new Rectangle(2.0,5.0);
		System.out.println(r.getWidth());
		System.out.println(r.getLength());
		System.out.println(r.getArea());
		System.out.println(r.getPerimeter());
		System.out.println(r.toString());
		
		
		Square s=new Square(4);
		System.out.println(s.getSide());
	
		System.out.println(s.toString());
		
		
		
		
		
		
		
		
		
		
		

	}

}
