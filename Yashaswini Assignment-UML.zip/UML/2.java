import java.util.Scanner;

public class InvoiceItem
{
    private String id;
    private String desc;
    private  int qty;
    private double unitPrice;
    
    public InvoiceItem(String id,String desc,int qty,double unitPrice){
    this.id=id;
    this.desc=desc;
    this.qty=qty;
    this.unitPrice=unitPrice;
        
    }
    
    public String getID(){
        return id;
    }
    public String getDesc(){
        return desc;
    }
    public int getQty(){
        return qty;
    }
    public  void setQty(int qty){
        this.qty=qty;
    }
    public double getUnitPrice(){
        return unitPrice;
    }
    public void UnitPrice(double unitprice){
        this.unitPrice=unitprice;
    }
    public double getTotal(){
    return unitPrice*qty;
    }
    public String toString(){
        return "InvoiceItem[id="+id+",desc="+desc+",qty="+qty+",unitPrice="+unitPrice+"]";
    }
    
    public  static void main(String[] args){
        InvoiceItem i=new InvoiceItem("11","Analyst",100,1000);
         System.out.println(i.toString());
        System.out.println(i.getID());
        
         System.out.println(i.getDesc());
          System.out.println(i.getQty());
           System.out.println(i.getUnitPrice());
            System.out.println(i.getTotal());
            
        
    }
    
    
    
    
    
    
}
    
    
    
    
    
    
    
    
    
    

     