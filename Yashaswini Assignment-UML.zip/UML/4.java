import java.util.Scanner;

public class keyboardScanner {
    
    public static void main(String[] args) {
  

        int    num1;
        double num2;
        double sum;
        String name;
        
        Scanner in = new Scanner(System.in);
        
       
        num1 = in.nextInt();
        System.out.print("Enter an integer:" +num1); 
       
        num2 = in.nextDouble();
        
       System.out.print("\nEnter a floating point number:" +num2);
        name = in.next();
          System.out.print("\nEnter your name: " +name);
        sum = num1 + num2;
        System.out.printf("\nHi! %1$s, the sum of %2$d and %3$.2f is %4$.2f \n", name, num1, num2, sum);
    }
}