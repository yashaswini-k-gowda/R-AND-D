import java.util.Scanner;

public class GradesAverage
{
 
  public static void main(String[] args)
  {
      int numStudents,i;
      int a=0;int n;
       int Average=0;
       double Average1;
      Scanner s=new Scanner(System.in);
      n=s.nextInt();
     
      int array[]=new int[n];
       System.out.print("Enter the number of students\n ");
      for(i=0;i<n;i++)
      {
          array[i]=s.nextInt();
        System.out.printf("Enter the grade for student %d: %d\n",i,array[i]);
if(array[i]>0 && array[i]<=100)
{
    
    Average=Average+array[i];
}
else

 
System.out.print("Invalid grade,try again...\n");

   

}

Average1=Average/n;
System.out.print("Average is:" +Average1);
      }
  
}