import java.util.Scanner;

public
     class pal
{  
 
   public static void main(String args[])

    {
      
  int x,y,z,a=0;
      
  Scanner in=new Scanner(System.in);
  
      x=in.nextInt();
   
   y=x;
       
   
 while(x>0)
  
  {
       
 z=x%10;
     
   a=a*10+z;
    
    x=x/10;
   
 }
          
   
       if(a==y)
{
  
            
          
  System.out.println("the Given number is Palindrome" );
 

         }
         
 else
          
{
           
System.out.println("the Given number is not a Palindrome");  

}
       
  
  }

}