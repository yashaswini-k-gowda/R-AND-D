import java.util.Scanner;

public class Gr{

	public static void main(String[] args) {
	    int ar[][]={{1,2,3},{3,6,7}};
	    int i,j;
	    int num;
	    int c=0;
	    Scanner s=new Scanner(System.in);
	    System.out.print("Enter the number to be searched\n");
	    num=s.nextInt();
	     for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            if(num==ar[i][j])
            
	    {
	       c++;
	    } 
    }
}
	 if(c==1)
	 {
	 System.out.print("Number exists\n");
	    }
	    else{
	    System.out.print("Number doesnot exists\n");
	        
	    }
              
}



	

}