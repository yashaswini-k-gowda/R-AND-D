import java.util.Scanner;

public class Gr{

	public static void main(String[] args) {
int newItem;
double discount;
double newItemPrice;

Scanner s=new Scanner(System.in);
newItem=s.nextInt();
discount=0.35*newItem;
newItemPrice=newItem-discount;
System.out.print(+newItemPrice);
	  
}



	

}