import java.util.Scanner;

public class Gr{

	public static void main(String[] args) {
int CTC;
Scanner s=new Scanner(System.in);
double a,b,c;

CTC=s.nextInt();
if(CTC>=0 && CTC<=180000)
{
    System.out.print("Tax Amount: NIL");
    
}
else if(CTC>180000 && CTC<=300000)
{
    a=0.1*CTC;
    System.out.print("Tax Amount: " +a);

}

else if(CTC>300000 && CTC<=500000)
{
    b=0.2*CTC;
    System.out.print("Tax Amount: " +b);

}
else if(CTC>500000 && CTC<=1000000)
{
    c=0.3*CTC;
    System.out.print("Tax Amount: " +c);

}

}

}