import java.io.*;
import java.util.*;
 import java.util.Scanner;
 public
class GFG {
    public static void main(String[] args)
{
 Scanner s=new Scanner(System.in);
int i=0,j,k=1,dif=0;
//int a[];
int n;  
n=s.nextInt();
int a[]=new int[n];


for(i=0;i<n;i++){
 a[i]=s.nextInt();


System.out.print(a[i] + " ");
}
   
   for(i=0;i<n;i++)
 {
       for(j=i+1;j<n;j++)
       {
           if(a[i]==a[j]){
              
             dif=Math.abs(i-j);   
          }
          
         else
       {
            
      break;}
      
         
       } 
    } 
           
    // System.out.print(dif);      
              if(dif<=k)
           {
           System.out.print("Is at most K");
           }
           else{
           System.out.print("Is not at most K");
       }
   
  }
}