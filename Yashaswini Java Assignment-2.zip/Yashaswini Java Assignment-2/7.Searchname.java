import java.util.Scanner;

public class Gr{

	public static void main(String[] args) {
	   String str[]={"Dave","Ann","George","Sam","Ted","Gag","Saj","Agati","Mary","Sam","Ayan","Mary","Kity","Meery","Smith","Johnson","Bill","Williams","Jones","Brown","Davis","Miller","Wilson","Moore","Taylor","Anderson","Thomas","Jackson"};
	   int length1=28;
	   Scanner s=new Scanner(System.in);
	   
	  int i=0,count=0;
	  String st="Mary";
	 
	 
	  for(i=0;i<length1;i++)
	  {
	      if(str[i]==st)
	      {
	      count++;
	      }
	  }
	  System.out.print(+count);
}



	