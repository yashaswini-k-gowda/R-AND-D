import java.util.Scanner;

public class MyClass {
    
public static void main(String args[]) 
{
       int i,j,n,t=0;
 
     int a[]={1,2,4,5,0,0,0,6};
  
     Scanner s=new Scanner(System.in);
 
        n=s.nextInt();
  
     for(i=0;i<n;i++){
  
   if(a[i]!=0)
     
{
 
    a[t++]=a[i];
  
   }
     
}


     while(t<n)
    
 {a[t++]=0;
   
 }
 
   for(j=0;j<n;j++)
 
       System.out.print(a[j]+" ");
  
         
       }
   
      
    
}
