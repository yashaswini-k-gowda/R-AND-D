import java.util.Scanner;

public class MyClass {
  
  public static void main(String args[]) {

        int x,y,z;
Scanner s=new Scanner(System.in);

x=s.nextInt();
y=s.nextInt();

z=x+y;
        
System.out.println("Sum of x+y = " + z);
    
}
}
