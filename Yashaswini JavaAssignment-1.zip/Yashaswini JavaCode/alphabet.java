import java.util.Scanner;
public class MyClass {
    public static void main(String args[]) {
       int alphabet=65,i,j,n;
Scanner s=new Scanner(System.in);
n=s.nextInt();  
for(i=1;i<n;i++)
{
   
    for(j=1;j<=i;j++)
    {
    System.out.print((char)alphabet);
    }
    alphabet++;

        System.out.println();
    }
}
}