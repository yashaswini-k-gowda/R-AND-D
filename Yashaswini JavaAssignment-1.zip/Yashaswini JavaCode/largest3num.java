import java.util.Scanner;

public class MyClass {
 

   public static void main(String args[])
 {
      
 int i,a,b,c,n;
  
    
int x[]={5,9,4,87,45};
   
    Scanner s=new Scanner(System.in);

   n=s.nextInt();
  
 if(n<3)
  
 {
    
  System.out.print("invalid"); 
 
     return;
   }
   
c=a=b=Integer.MIN_VALUE;
  
 for(i=0;i<n;i++)
  
 {
       if(x[i]>a)
  
     {
        
   c=b;
           
b=a;
          
 a=x[i];
     
  }
       
else if(x[i]>b)
 
      {
     
      
c=b;
        
   b=x[i];
    
   }
       
else if(x[i]>c)
 
 
     c=x[i];
 
  }
   
   
  System.out.print("largest numberis " +a +" "+b +" "+c);
   
        
       }
        
 
    
}