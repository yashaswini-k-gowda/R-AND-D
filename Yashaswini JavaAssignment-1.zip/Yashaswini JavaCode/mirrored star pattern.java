import java.util.Scanner;

public class MyClass {
   
 public static void main(String args[]) {
    
   int i,j,n;
       
      
 Scanner s=new Scanner(System.in);
   
    n=s.nextInt();
      
 for(i=1;i<n;i++)
       {
    
       for(j=1;j<=n;j++)
         
 
 {
              
 if(j<=n-i)
              

 {
                   
               
          
     System.out.print(" ");
              
 }
       

else
       
{
          
 System.out.print("*");
 
      }
       
    }
       
 System.out.println();
  
  
       }  
   
 }

}


