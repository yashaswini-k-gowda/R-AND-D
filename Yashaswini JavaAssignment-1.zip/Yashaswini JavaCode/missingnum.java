import java.util.Scanner;

public class MyClass {
  
  public static void main(String args[])

 {
   
    int j,n,t;
     
 
int a[]={1,2,4,5,6};
 
     
 Scanner s=new Scanner(System.in);



         n=s.nextInt();
  
 

     
       t=(n+1)*(n+2)/2;


       for(j=0;j<n;j++)
   
  {
     
  
t=t-a[j];
   
  
  }
 
      
       
       
 System.out.println(+t);
        
   
       }
         
  
  
}

