package operation;

interface oper{
	void check(int a);
	

}
