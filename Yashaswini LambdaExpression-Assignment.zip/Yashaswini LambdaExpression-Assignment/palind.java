package operation;

interface palind{
	void check(int a);
	



}
