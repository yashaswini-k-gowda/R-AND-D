package operation;

public class test{
	public static void main(String[] args) {
		
		oper op=(int a)->{
			if(a%2 ==0)
			{
				System.out.println("false,it is even number");
			}
			else
			{
				
				System.out.println("true,it is odd number");
				
			}
		};
		op.check(6);
		
		
		test2 t=(int a)->{
			int i=2;
			while(i<=a/2)
			{
				if(a % i==0)
				{
					System.out.println("false,it is not prime");
					break;
				}
				else
				{
					
					System.out.println("true,it is prime");
					break;
			}
				
			
		}
		
		};
		t.check(11);
		
		palind p=(int a)->{
		int x,y,z;
		x=0;
		 y=a;
		
		while(a>0)
			  
		  {
		       
 z=a%10;
		    x=x*10 + z;
		    
		    a=a/10;
		   
		 }
		          
		   
		      
			if(x==y)
		{
		  
		            
		          
		  System.out.println("true ,given number is palindrome");
		 

		         }
		         
		 else
		          
		{
		           
		System.out.println("false,given number is not a palindrome");

		}
		       
		  
		  };
		  p.check(121);
		  

		}
		
		
		
	}


