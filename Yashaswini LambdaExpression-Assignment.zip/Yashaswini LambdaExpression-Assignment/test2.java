package operation;

interface test2{
	void check(int a);
	

}