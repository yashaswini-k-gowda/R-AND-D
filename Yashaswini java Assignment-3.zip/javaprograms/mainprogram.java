package uml;

public class mainprogram {

	public static void main(String[] args) {
		
		Student s=new Student("Yashu.K","bangalore","java",2018,12000);
		Person a=new Person("Yashaswini","Bangaluru");
		System.out.println(a.getName());
		System.out.println(a.getAddress());
		System.out.println(a.toString());
		
		
		System.out.println(s.getProgram());
		System.out.println(s.getYear());
		System.out.println(s.getFee());
		System.out.println(s.toString());
Staff st=new Staff("Yashu","bangalore","Jubilee",20000);
System.out.println(st.getSchool());
System.out.println(st.getPay());
System.out.println(st.toString());
		
	}

}
