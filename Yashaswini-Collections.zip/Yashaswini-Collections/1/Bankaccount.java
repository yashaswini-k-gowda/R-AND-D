package collect;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

public class Bankaccount {

	public static void main(String[] args) {
		//savingAccount s=new savingAccount();
		Set<savingAccount> sy=new TreeSet<savingAccount>();
		
		sy.add(new savingAccount("120000",108,"yashu",true));
		sy.add(new savingAccount("90000",103,"ash",false));
		sy.add(new savingAccount("20000",108,"nandu",true));
		sy.add(new savingAccount("120000",101,"tharu",true));
		
		
		for(savingAccount a:sy)
		{
			
			System.out.println(a.acc_balance+","+a.acc_ID+","+a.accountHoldername+","+a.isSalaryAccount);
		}
		
			
	}
}


