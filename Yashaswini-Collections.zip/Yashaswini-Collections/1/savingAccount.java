package collect;
import java.util.*;
import java.util.Arrays;

public class savingAccount implements Comparable<savingAccount> {
	String acc_balance;
	int acc_ID;
	String accountHoldername;
	boolean isSalaryAccount;
	


public   savingAccount(String acc_balance,int acc_ID,String accountHoldername,boolean isSalaryAccount)
{
    	this.acc_balance= acc_balance;
    	this.acc_ID= acc_ID;
    	this.accountHoldername=accountHoldername;
    	this.isSalaryAccount=isSalaryAccount;
}
 public String getAcc_balance()
 
{
	return acc_balance;
}
 public void setAcc_balance(String ac_balance)
 {
	 this.acc_balance= acc_balance;
 }
 public int getAcc_ID()
 
 {
 	return acc_ID;
 }
  public void setAcc_ID(int acc_ID)
  {
 	 this.acc_ID= acc_ID; 
 
  }
 
  public String getAccountHoldername()
  
  {
  	return accountHoldername;
  }
   public void setaccountHoldername(String accountHoldername)
   {
  	 this.accountHoldername= accountHoldername; 
  
   }
   public boolean getIsSalaryAccount()
   
   {
   	return isSalaryAccount;
   }
    public void setIsSalaryAccount(boolean isSalaryAccount)
    {
   	 this.isSalaryAccount= isSalaryAccount; 
   
    }
 public int compareTo(savingAccount b)
 {
	 if(this.acc_ID==b.getAcc_ID())
	 {
		 return 0;
		 
	 }
	 else if(this.acc_ID < b.getAcc_ID())
	 {
		 
	 
	 return -1;
	 
	 }
	return 1;
 }
}

