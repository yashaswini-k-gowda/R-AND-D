package collect;

public class Employee_information {
	int empID;
	String  Employee_name;
	String employee_designation;
	int employee_salary;
	String  employee_comm;
	public  Employee_information(int empID,String  Employee_name,String employee_designation,int employee_salary,String  employee_comm) 
	{
		this.empID=empID;
		this.employee_designation=employee_designation;
		this.Employee_name= Employee_name;
		this.employee_salary= employee_salary;
		this.employee_comm=employee_comm;
		}

public int getEmpID() {
	return empID;
}

public void setEmpID(int empID) {
	this.empID=empID;
}
public String getEmployee_Name() {
	return  Employee_name;
}

public void setEmployee_Name(String  Employee_name) {
	this.Employee_name= Employee_name;
}
public String getEmployee_designation() {
	return employee_designation;
}

public void setEmployee_designation(String employee_designation) {
	this.employee_designation=employee_designation;
}
public double getEmployee_Salary() {
	return employee_salary;
}

public void setEmployee_Salary(int employee_salary) {
	this.employee_salary= employee_salary;
}
public String getEmployee_comm() {
	return employee_comm;
}

public void setEmployee_comm(String employee_comm) {
	this.employee_comm=employee_comm;
}

public String toString() {
	return empID+" " + Employee_name+ " " + employee_designation +" "+ employee_salary+" " + employee_comm;

}



}



