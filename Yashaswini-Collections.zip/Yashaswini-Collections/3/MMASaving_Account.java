package collect;

public class MMASaving_Account {
String accountID;
String accountholder;
int account_balance;
boolean isSalaryaccount;

public MMASaving_Account(String accountID,String accountholder,int account_balance,boolean isSalaryaccount)
{
	this.accountID=accountID;
	this.accountholder=accountholder;
	this. account_balance= account_balance;
	this.isSalaryaccount=isSalaryaccount;
	
}
public String getAccountID() {
	return accountID;
}

public void setAccountID(String accountID) {
	this.accountID=accountID;
	
}
	
public String getAccountholder() {
	return accountholder;
}

public void setAccountholder(String accountholder) {
	this.accountholder=accountholder;
}
	public int getAccount_balance() {
		return account_balance;
	}

	public void setAccount_balance(int account_balance) {
		this. account_balance= account_balance;
	}
		public boolean getIssalaryAccount() {
			return isSalaryaccount;
		}

		public void setIssalaryAccount(boolean isSalaryaccount) {
			this.isSalaryaccount=isSalaryaccount;
			
}

		public String toString() {
			return accountID+" " + accountholder+" " + account_balance+" " + isSalaryaccount;

		}








}
