package collect;
import java.util.*;
//import java.util.List;
import java.util.ArrayList;

public class emplo_MMA {

	public static void main(String[] args) {

Map<Employee_information,MMASaving_Account> m=new HashMap();
m.put(new Employee_information(121,"yashu","developer",10000,"eng"),new MMASaving_Account("sd2122","Yashaswini",12000,true));

m.put(new Employee_information(151,"ash","developer",23000,"eng"),new MMASaving_Account("ed3122","Yash",67000,false));


for(Map.Entry m1:m.entrySet()) {
	System.out.println(m1.getKey());
	System.out.println(" "+m1.getValue());


}







	}

}
