package CollectionsActivity;


import java.util.*;

public class Temp {
	
	@SuppressWarnings("resource")
	public static void main(String args[])
	{
		
		TreeMap<Product,String> tmap=new TreeMap<Product,String>();
		int a[]=new int[5];
		String n[]=new String[5];
		String d[]=new String[5];

		Product p[]=new Product[5];
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter product ids");
			a[i]=sc.nextInt();
			
			System.out.println(" And names");
			n[i]=sc.next();
			
			System.out.println("Description");
			d[i]=sc.next();
			
			p[i]=new Product(a[i],n[i]);
			tmap.put(p[i],d[i]);
			
		}
		
		 Set set = tmap.entrySet();
		 
		    // Get an iterator
		    Iterator i = set.iterator();
		 
		    // Display elements
		    while(i.hasNext()) {
		      Map.Entry me = (Map.Entry)i.next();
		      System.out.print(me.getKey() + ": ");
		      System.out.println(me.getValue());
		
		
		
		
	}

}
}
