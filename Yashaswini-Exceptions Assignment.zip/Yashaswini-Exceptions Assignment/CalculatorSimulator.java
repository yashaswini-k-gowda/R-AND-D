


public class CalculatorSimulator {

	public static void main(String[] args) 
		
	{
	
   TaxCalculator c=new TaxCalculator();
   
   try
   {
	   System.out.println("Tax Amount is "+c.calculateTax("Ron", false, 35000));
	  // System.out.println("Tax Amount is "+c.calculateTax("Tim", true, 1000));
   
	  // System.out.println("Tax Amount is "+c.calculateTax("Jack", true, 55000));
	   //System.out.println("Tax Amount is "+c.calculateTax("", true, 30000));
   
   
   }
   catch(CountryNotValidException e)
   {e.printStackTrace();
   
   }
   
   
   catch(EmployeeNameInvalidException f)
   {f.printStackTrace();
   
   }
   
   
   catch(TaxNotEligibleException i)
   {i.printStackTrace();
   
   }
   
   
   
   
   
	}
	
}
