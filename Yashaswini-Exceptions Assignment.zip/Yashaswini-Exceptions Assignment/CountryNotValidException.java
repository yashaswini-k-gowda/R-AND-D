

public class CountryNotValidException extends Exception {
CountryNotValidException(){
	super("The employee should be an indian citizen for calculating tax");
		
}
}
