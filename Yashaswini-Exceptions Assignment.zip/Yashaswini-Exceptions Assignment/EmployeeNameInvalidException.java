

public class EmployeeNameInvalidException extends Exception {
	EmployeeNameInvalidException(){
		super("The employee name cannot be empty");
	}
}
