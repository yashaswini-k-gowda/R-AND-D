


public class TaxNotEligibleException extends Exception {
	TaxNotEligibleException(){
		super("The employee does not need to pay tax");
		
	}
}
