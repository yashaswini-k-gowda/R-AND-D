
public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		KidUsers k=new KidUsers(10,"Kids");
		
		k.registerAccount();		
		
		k.requestBook();
		System.out.println("\n");
	
		
		AdultUser a=new AdultUser(5,"Kids");
		
		a.registerAccount();
		
	    a.requestBook();
		
	System.out.println("\n\n\n\n\n");
	
	System.out.println("Checking for Another inputs\n");
	
	
	KidUsers k1=new KidUsers(18,"Fiction");
	k1.registerAccount();
	
	k1.requestBook();
	System.out.println("\n");
	
	AdultUser a1=new AdultUser(23,"Fiction");
	a1.registerAccount();
	
	a1.requestBook();
	System.out.println("\n");
	
	}

}
