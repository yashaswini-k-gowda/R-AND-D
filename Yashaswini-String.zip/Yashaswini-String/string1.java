package collections;
import java.util.*;
public class string1 {
	public static void main(String[] args) {
		String text="Welcome to java World ";
		char c='a' ;
		
		char x=text.charAt(5);
		
		System.out.println(x);
		String text2="Welcome";
		System.out.println(text.equalsIgnoreCase(text2));
		
		
		String text3="Let us learn";
	String s4=text.concat(text3);
	System.out.println(s4);
	
		System.out.println(s4.indexOf(c));
		String s5=s4.replaceAll("a", "e");
		
		System.out.println(s5);
		
	String s6=s5.substring(4, 10);
	System.out.println(s6);
String s7=s4.toLowerCase();
	System.out.println(s7);
	
		
	}
	}
	
	

	
	
	
	


