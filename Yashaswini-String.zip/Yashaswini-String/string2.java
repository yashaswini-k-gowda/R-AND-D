package collections;
import java.util.*;
public class string2 {
public static void main(String[] args)
{
	StringBuffer sb=new StringBuffer("This is StringBuffer");
	sb.append(" This is a sample program");
	System.out.println(sb);
	
	
	sb.insert(21,"Object");
	System.out.println(sb);
	
	StringBuffer sb1=new StringBuffer(sb);
	sb1.reverse();
	System.out.println(sb1);
	
	StringBuffer sb2=new StringBuffer(sb);
	sb2.replace(14, 20, "Builder");
	System.out.println(sb2);
	
	
}
}
