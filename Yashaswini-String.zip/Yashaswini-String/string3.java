package collections;
import java.util.*;
import java.util.Arrays;

public class string3 {

	public static void main(String[] args) {
		String name="C:\\IBM\\DB2\\PROGRAM\\DB2COPY1.EXE";
	
	
String[] arr=name.split("\\\\");

System.out.println(Arrays.toString(arr));
System.out.print("Drive:"+arr[0]);
System.out.println("\\");
System.out.print(arr[1]);
StringBuilder s2=new StringBuilder();
concat2(s2);
System.out.print(s2);
System.out.print(arr[2]);
StringBuilder s3=new StringBuilder();
concat2(s3);
System.out.print(s3);
System.out.println(arr[3]);

System.out.println("File:"+arr[4]);

	}
	
public static void concat2(StringBuilder s2)
{
	s2.append("||");
	
}
}
