//import java.lang.Exception;
public class MyCalculator {

	int n; int p;
	int result;
	
	public int method(int n,int p)throws Exception
	{
		
		if(n<0 || p<0)
		{
			throw new Exception("n and p should not be negative");
			
		}
		
		else if(n==0 && p==0)
		{
			throw new Exception("n or p should not be zero");
		}
		
		else {	
		
		int result=(int) Math.pow(n,p);
		return result;

	}
	
	}
	
}
