
public class classexception {
	public static void main(String[] args) throws Exception
	
	{
		MyCalculator m=new MyCalculator();
		
			   System.out.println(m.method(0,0));
		
		   
				
		   }
		   
		   
	
	
}
