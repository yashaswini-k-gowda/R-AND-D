
@SuppressWarnings("serial")
public class AgeNotWithinRangeException extends Exception {
	AgeNotWithinRangeException(){
		super("Age is not within range");
	}
}
