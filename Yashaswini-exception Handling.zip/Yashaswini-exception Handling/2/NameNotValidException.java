
@SuppressWarnings("serial")
public class NameNotValidException extends Exception {
	NameNotValidException(){
		super("Name is not valid");
	}
}
