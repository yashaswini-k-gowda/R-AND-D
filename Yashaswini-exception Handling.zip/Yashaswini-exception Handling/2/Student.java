import java.util.regex.Pattern;

public class Student{
	
	int rollno;
	String name;
	int age;
	String course;

public void Class(int rollno,String name,int age,String course) throws AgeNotWithinRangeException,NameNotValidException
{
	this.rollno=rollno;
	this.name=name;
	this.age=age;
	this.course=course;
	
	if(age<=15 || age>=21)
 { 
	 throw new AgeNotWithinRangeException();
 }
 
 else if(!(Pattern.matches("[a-zA-Z]+",name)))
	 
 {
	 throw new NameNotValidException();
	 
 }
 
 
 
}
}