
public class fuction {
public  static void  main(String[] args)
{
	Student m=new Student();
	try
	   {
		   m.Class(20,"bindu",23,"BE");
	   }
	catch(AgeNotWithinRangeException  f)
	   {
		f.printStackTrace();
	   }
	catch(NameNotValidException  e)
	   {
		e.printStackTrace();
	   }
}
}
