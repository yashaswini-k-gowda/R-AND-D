
public class InvalidDayException extends Exception {
	InvalidDayException(){
		super("Invalid day");
	}
}
