
public class InvalidMonthException extends Exception {
	InvalidMonthException(){
		super("invalid month");
		
	}
}
