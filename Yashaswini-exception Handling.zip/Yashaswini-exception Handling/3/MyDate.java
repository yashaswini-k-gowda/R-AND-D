
public class MyDate {
int day;
int month;
int year;
	public void  ma(int day,int month)throws InvalidDayException,InvalidMonthException
	{
		if(day>31)
		{
			throw new InvalidDayException();
		}
		
		
		else if(month>12)
		{
			throw new InvalidMonthException();
		}
		else
			System.out.println("Valid Date");
	}
}
