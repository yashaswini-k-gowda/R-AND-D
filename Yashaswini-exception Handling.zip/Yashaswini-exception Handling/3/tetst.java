
public class tetst {
public static void main(String[] args) {
	for(int i=0;i<7;i++)
	{
		String date=args[i];
		String day=date.substring(0, 2);
		String month=date.substring(3,5);
		int d=Integer.parseInt(day);
		int e=Integer.parseInt(month);
		MyDate c=new MyDate();
		try {
			c.ma(d, e);
		}
		
		catch(InvalidDayException e1)
		{
			e1.printStackTrace();
			
	}
		catch(InvalidMonthException e2) 
		{
			e2.printStackTrace();
			
			
		}
}
}
}