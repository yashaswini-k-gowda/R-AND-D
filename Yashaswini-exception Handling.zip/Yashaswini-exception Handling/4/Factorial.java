
public class Factorial {
int num;
int fact=1;
	public int getFactorial(int num)throws InvalidInputException,FactorialException
	{int fact=1;
		if(num<2)
		{
			throw new InvalidInputException();
			
		}
		
		else if(num>Integer.MAX_VALUE)
		{
			throw new FactorialException();
		}
		else
		{
			
		
			for(int i=1;i<=num;i++)
			{
				
				fact=fact*i;
			}
			
		return fact;
		}
	}
	
}
