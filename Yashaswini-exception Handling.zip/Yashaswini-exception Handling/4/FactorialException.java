
public class FactorialException extends Exception {
	FactorialException(){
		super("value reached");
	}
}
