
@SuppressWarnings("serial")
public class InvalidInputException extends Exception {
	InvalidInputException(){
		super("invalid input");
	}
}
