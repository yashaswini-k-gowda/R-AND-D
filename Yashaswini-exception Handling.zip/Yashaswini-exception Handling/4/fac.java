
public class fac {

	public static void main(String[] args) {
		
		Factorial h=new Factorial();
		
		try {
			System.out.println(h.getFactorial(1));
			
		}
		catch( FactorialException e)
		{
			e.printStackTrace();
			
		}
		catch(InvalidInputException f)
		{
			f.printStackTrace();
			
		}
	}

}
