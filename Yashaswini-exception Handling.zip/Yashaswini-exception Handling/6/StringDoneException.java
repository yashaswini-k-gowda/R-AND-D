
public class StringDoneException extends Exception {
	StringDoneException(){
		
	}
}
