
public class StringTooLongException extends Exception {
	StringTooLongException(){
		
	}
}
