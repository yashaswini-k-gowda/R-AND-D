import java.util.Scanner;
public class charac {
String s;
public String Charstring() throws StringTooLongException,StringDoneException{
	Scanner st=new Scanner(System.in);
	System.out.println("enter string");
	s=st.next();
	
	if(s.length()>=20)
{
		
	throw new StringTooLongException();
	
}
	
	if(s.length()>20 || s.equals("DONE"))
	{
		throw new StringDoneException();
	}
return s;
}

}
