
public class stringlo {
public static void main(String[] args) {
	charac c=new charac();
	try {
		System.out.println(c.Charstring());
		
	}
	catch(StringDoneException e)
	{
		e.printStackTrace();
	}
	catch(StringTooLongException e)
	{
		e.printStackTrace();
	}
}
}
