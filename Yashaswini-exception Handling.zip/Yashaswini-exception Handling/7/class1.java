import java.util.Scanner;
import java.util.*;
public class class1 {
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
			
			boolean second=true;
	float sum=0;
	int ch=0;
	
	while(second) {
		boolean done=true;
		try {
			while(done)
			{
				try {
					
			
			System.out.println("enter number:");
	float input=s.nextFloat();
	sum=sum+input;
				}
			
		
			catch(InputMismatchException e) {
			ch++;
			s=new Scanner(System.in);
			done=false;
				}
			if(!done && ch<1)
				break;
			if(ch>=1) {
				
			
				System.out.println("Input error.try again");
				float input=s.nextFloat();
				sum=sum+input;
				done=true;
			}
	}
		}
	catch(InputMismatchException ne) {
		second=false;
	}
	}
		System.out.println(+sum);
	
	
}

}
