package com.example.databasespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseSpringApplication.class, args);
	}
}
