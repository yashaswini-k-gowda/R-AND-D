package com.cloud.dbservice.resource;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.dbservice.model.Details;

@RestController
@RequestMapping("/rest/db")
public class DbService {
	
	@Autowired
	private DetailsRepository detailsRepository;
	
	/*@GetMapping("/{username}")
	public List<String> getDetails(@PathVariable("username") String username ){
		
		
		return detailsRepository.findByUsername(username);

	}*/
	
	@GetMapping("/{id}")
	public Details getDetailsById(@PathVariable("id") ObjectId id ){
		return detailsRepository.findBy_id(id);

	}
	
	
	@PostMapping("/add")
	public Details addDetails(@Valid @RequestBody Details details)
	{
		detailsRepository.save(details);
		return details;
	}
	
	@PutMapping("/update/{id}")
	public Details updateDetailsById(@PathVariable("id") ObjectId id, @Valid @RequestBody Details details)
	{
		//Details findBy_id(ObjectId _id)
		
		details.set_id(id);
		return detailsRepository.save(details);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public void deletePet(@PathVariable("id") ObjectId id) {
	    detailsRepository.delete(detailsRepository.findBy_id(id));
	  }

	@GetMapping("/")
	public List<Details> getAllPets() {
	  return detailsRepository.findAll();
	}

	
	
}
