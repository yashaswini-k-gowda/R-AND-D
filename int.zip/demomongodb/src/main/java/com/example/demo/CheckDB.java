package com.example.demo;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;

/**
 * Java MongoDB : Query document
 * 
 * @author mkyong
 * 
 */
public class CheckDB {

	public static void insertDummyDocuments(DBCollection collection) {

		List<DBObject> list = new ArrayList<DBObject>();

		Calendar cal = Calendar.getInstance();

		for (int i = 1; i <= 5; i++) {

			BasicDBObject data = new BasicDBObject();
			data.append("number", i);
			data.append("name", "mkyong-" + i);
			// data.append("date", cal.getTime());

			// +1 day
			cal.add(Calendar.DATE, 1);

			list.add(data);

		}

		collection.insert(list);

	}

	public static void main(String[] args) {

	try {

	  Mongo mongo = new Mongo("localhost", 27017);
	  DB db = mongo.getDB("user");

	  // get a single collection
	  DBCollection collection = db.getCollection("dummyColl");

	  insertDummyDocuments(collection);


	
		  System.out.println("\n4. Find where name = 'Mky.*-[1-3]', case sensitive example");
	  BasicDBObject regexQuery = new BasicDBObject();
	  regexQuery.put("name",
		new BasicDBObject("$regex", "^(/mk/)")
                    .append("$options", "i"));

	  System.out.println(regexQuery.toString());

	  DBCursor cursor8 = collection.find(regexQuery);
	  while (cursor8.hasNext()) {
		System.out.println(cursor8.next());
	  }

	  

	  System.out.println("Done");

	 }
	  catch (MongoException e) {
		e.printStackTrace();
	 }

	}
}