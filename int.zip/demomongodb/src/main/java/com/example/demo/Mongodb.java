package com.example.demo;
 
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


import com.mongodb.client.model.Indexes;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.TextSearchOptions;
import com.mongodb.client.model.Projections;
import org.bson.Document;
 
public class Mongodb {
    public static void main(String[] args) {
      
    	MongoClient mongoClient = new MongoClient();
    	MongoDatabase database = mongoClient.getDatabase("user");
    	MongoCollection<Document> collection = database.getCollection("products");
    	collection.createIndex(Indexes.text("pname"));
    	long matchCount = collection.count(Filters.text("sofa fan"));
    	System.out.println("Text search matches: " + matchCount);
    	 Block<Document> printBlock = new Block<Document>() {
    	        @Override
    	        public void apply(final Document document) {
    	            System.out.println(document.toJson());
    	        }
    	    };
 
   
    }
 
}