package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "products")
public class Search {

	@Id
	
	String query;
	
	public Search( String query ) {
		this.query = query;	}
	

	
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	
	@Override
	public String toString() {
		return "Query [query=" + query + "]";
	}
	
	
}
