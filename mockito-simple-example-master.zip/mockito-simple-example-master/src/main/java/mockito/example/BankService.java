package mockito.example;

public interface BankService {

	void makePayment(String employeeId, int salary);

}
