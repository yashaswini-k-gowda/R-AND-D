package mockito.example;

import java.util.List;

public interface EmployeeDB {

	List<Employee> getAllEmployees();

}
