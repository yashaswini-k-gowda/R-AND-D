package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.service.ProductService;
import com.example.demo.service.UserService;

@RestController
public class ProductController {

	
	@Autowired
	ProductService pservice;
	
	
	@RequestMapping(value="/postad", method = RequestMethod.POST)
	public ModelAndView addProduct(Model model, @ModelAttribute("product") Product product, @ModelAttribute("pname")String pname, @ModelAttribute("pcategory")String pcategory, @ModelAttribute("price")double price, @ModelAttribute("pdesc")String pdesc, @ModelAttribute("uname")String uname, @ModelAttribute("umobile")String umobile, @ModelAttribute("uemail")String uemail) {
		if((pservice.findByPname(pname) == null)) {
			Product prod= pservice.addProduct(pname, pcategory, price, pdesc, uname, umobile, uemail);
			ModelAndView mav = new ModelAndView(); 
//			mav.addObject("users", user1);
			System.out.println("added prod");
			mav.setViewName("index");
			return mav;
		}
		else {
			System.out.println("vvv");
			ModelAndView mav = new ModelAndView(); 
			model.addAttribute("msg", "Give a unique name to your product");
			mav.setViewName("postad");
			return mav;
		}
	}
	
	@RequestMapping(value="/electronics", method = RequestMethod.GET)
	public ModelAndView electronics() {
		String category= "Electronics and Appliances";
		List<Product> elec= new ArrayList<>();
		elec.addAll( pservice.findByPcategory(category));
		System.out.println(elec.size());
		for(int i=0;i<elec.size();i++){
		    System.out.println(elec.get(i).getPname());
		} 
		ModelAndView mav1= new ModelAndView();
		mav1.addObject("category", elec);
		mav1.setViewName("electronics");
		return mav1;
		
	}
	
	@RequestMapping(value="/productdisplay", method = RequestMethod.POST)
	public ModelAndView searchbar(@ModelAttribute("search")String search) {
		if(pservice.findByPname(search) != null)
		{
			ModelAndView mav2= new ModelAndView();
			mav2.addObject("product", search);
			mav2.setViewName("productdisplay");
			return mav2;
		}
		else {
			ModelAndView mav2= new ModelAndView();
//			mav2.addObject("product", search);
			mav2.setViewName("index");
			return mav2;
		}
		
	}
}